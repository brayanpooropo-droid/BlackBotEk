@rem Gradle wrapper for Windows
@if "%DEBUG%"=="" @echo off
@setlocal
set JAVA_EXE=java.exe
set CLASSPATH=%~dp0gradle\wrapper\gradle-wrapper.jar
"%JAVA_EXE%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
@endlocal
